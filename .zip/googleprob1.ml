(*let input = ref "" in

let get_args () : unit =
    input := Array.get Sys.argv 1
;;
*)

let read_file filename = 
let lines = ref [] in
let chan = open_in filename in
try
  while true; do
    lines := input_line chan :: !lines
  done; []
with End_of_file ->
  close_in chan;
  List.rev !lines
;;

read_file "testprob1.txt";;

(*

let rec choose_list n m = 
  match n with 
    | 0 -> if (m = 0) then [[]] else []
    | k -> (choose_list (n-1) m)@(List.map (fun lst -> lst @ [n-1]) (choose_list (n-1) (m-1)))
;;


let get_best arr n =
  let totalsum = Array.fold_right (+) arr 0 in
  let summm lst = List.fold_right (fun x prev -> (Array.get arr x)+prev) lst 0 in
  let sums = List.map (fun lst -> (lst,summm lst)) (choose_list (2*n) n) in
  let newsums = List.map (fun (l,s) -> (l,abs (2*s - totalsum)) ) sums in
  let compare_bla (l1,f1) (l2,f2) = compare f1 f2 in 
  let sorted = List.sort compare_bla newsums in
  let (l,v) = List.hd sorted in
  v
;;
(*

let run () = 
  Printf.printf "\n1:";
  get_best [|1;2;3;4;5;6;7;8|] 4;

  Printf.printf "\n2:";
  get_best [|1;1;1;1;1;1;1;1000|] 4;


  Printf.printf "\n3:";
get_best [|13;17|] 1


;;
*)
run ();;
*)
