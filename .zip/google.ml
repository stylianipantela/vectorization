
let print_list (print: 'a -> unit) (lst: 'a list) : unit =
  let rec print_list_h print lst =
    match lst with
      | [] -> Printf.printf ""
      | hd::tl -> print hd; Printf.printf ";"; print_list_h print tl
  in
  Printf.printf "["; print_list_h print lst; Printf.printf "]"
;;

let print_int n = Printf.printf "%d" n ;;

let rec gen n =
  if (n<=0)
  then [[]]
  else (List.map (fun x -> 0::x) (gen (n-1)))@(List.map (fun x -> 1::x) (gen (n-1)))
;;

let rec nats n =
  if (n<=0) then [0]
  else n::(nats (n-1))
;;

let bla n arr1 arr2 =
  let bla2 = nats (n-1) in
  let lst = List.map (fun x -> if ((Array.get arr2 x) = 0) then 0 else (Array.get arr1 x)) bla2 in
  let sum = List.fold_right ((+)) lst 0 in
  if (sum = 1000) then (
  
  Printf.printf "\nList: ";
  print_list print_int lst;
  print_int (List.fold_right ((+)) lst 0) )
  
;;


let func lst n =
  let arr1 = Array.of_list lst in
  let lstarr2 = gen n in
  List.map (fun x -> bla n arr1 (Array.of_list x)) lstarr2
;;

let run () =
(*
  func [117;144;44;143;9;171;54;89;62;90;216;27;179;125;161;197] 16 ;; *)
func [81;119;221;261;39;65;53;197;67;222;91;117;260;234;208;52] 16 ;;
func [432;256;17;548;480;336;224;452;128;404;208;384;49;160;352;272] 16 ;;

run () ;;
