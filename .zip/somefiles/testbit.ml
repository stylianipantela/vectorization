open Types;;
open Graphmatrix;;


(* PART 1 - READ A BITMAP FILE AND CONVERT IT TO A BICOLOR MATRIX *)

(* BITMAPFILEHEADER is 14 bytes long, BITMAPINFOHEADER is 40 bytes long
So, skip the first 54 bytes, i.e. elements of the array
width = 18-22 arrays
height = 22-2
padding = (4 - (width * 3) mod 4) mod 4;
*)

let get_bytes_from_file filename : int list =
  let ch = open_in filename in
  let lst = ref [] in
  try
    while true;
    do
      lst := (input_char ch) :: (!lst);
    done;
    []
  with End_of_file ->
    close_in ch;
    List.map (int_of_char) (List.rev (!lst))
;;


exception ContractViolation;;
exception BlackWhite;;


let bytes_to_matrix (l: int list) : BiColorMatrix.matrix =
  let length = List.length l in

  if (length <= 54) then raise ContractViolation
  else if (not (((length - 54) mod 3) = 0)) then raise ContractViolation
  else
    ( 
      let width = (List.nth l 22) + ((List.nth l 21) * 16) + 
	((List.nth l 20) * 16 * 16) + ((List.nth l 19) * 16 * 16 * 16) in
      let height = (List.nth l 23) + ((List.nth l 24) * 16) + 
	((List.nth l 25) * 16 * 16) + ((List.nth l 26) * 16 * 16 * 16) in
      let padding = (4 - ((width * 3) mod 4)) mod 4 in
      let myMatrix =  BiColorMatrix.initialize height width in

      let rec extract (l: int list) (i: int) : int list =
	if (i = 54) then l
	else match l with
          | [] -> []
          | h::t -> extract t (i + 1) in
      
      let rec fix_padding (l: int list) (cur_width: int) (width: int) (pad: int) : int list =
	let rec remove_padding (l: int list) (pad: int) (cur_pad: int) : int list =
          if (cur_pad = pad) then l
          else( match l with
	    | [] -> []
	    | h::t -> remove_padding t pad (cur_pad + 1)) in
	match l with
	  | [] -> []
	  | h::t -> if (cur_width = width) 
            then fix_padding (remove_padding l pad 0) (cur_width + pad) width pad
            else h:: (fix_padding t (cur_width + 1) width pad) in
      
      let update_coords (x: int)  (y: int)  (width: int) : (int * int) =
        if (y = width - 1) then (x+1, 0)
        else (x, y+1) in

      let rec store (l: int list) (m: BiColorMatrix.matrix) ((x,y): (int * int)) (width: int) : BiColorMatrix.matrix =
        match l with
          | [] -> m
          | h::[] -> raise ContractViolation
          | h::t::[] -> raise ContractViolation
          | r::g::b::t -> if ((r,g,b) = (0,0,0)) then store t (BiColorMatrix.set m y x Black) (update_coords x y width) width
                        else if (r,g,b) = (255,255,255)
                        then store t (BiColorMatrix.set m y x White) (update_coords x y width) width
                        else raise BlackWhite
     in
    store (fix_padding (extract l 0) 0 width padding) myMatrix (0,0) width)

let bitmap_to_matrix (file: string) : (BiColorMatrix.matrix) = 
  bytes_to_matrix (get_bytes_from_file file)
;;

let width (l: int list) : int =
  let length = List.length l in

  if (length <= 54) then raise ContractViolation
  else if (not (((length - 54) mod 3) = 0)) then raise ContractViolation
  else
        (List.nth l 18) + ((List.nth l 19) * 16) + 
	((List.nth l 20) * 16 * 16) + ((List.nth l 21) * 16 * 16 * 16);;

let width_bit (file: string) : int = 
  width (get_bytes_from_file file)
;;

Printf.printf "here%d" (width_bit "testinputs/small.bmp");;

let rec print_list lst =
  match lst with
    | [] -> Printf.printf ""
    | hd :: tl -> Printf.printf "%d\n" hd; (print_list tl)
;;
(*print_list (get_bytes_from_file "testinputs/small.bmp");;*)

let rec remove_padding (l: int list) (pad: int) (cur_pad: int) : int list =
          if (cur_pad = pad) then l
          else( match l with
	    | [] -> []
	    | h::t -> remove_padding t pad (cur_pad + 1));;

 let rec fix_padding (l: int list) (cur_width: int) (width: int) (pad: int) : int list =
	let rec remove_padding (l: int list) (pad: int) (cur_pad: int) : int list =
          if (cur_pad = pad) then l
          else( match l with
	    | [] -> []
	    | h::t -> remove_padding t pad (cur_pad + 1))
        in
	match l with
	  | [] -> []
	  | h::t -> if (cur_width = width) 
            then fix_padding (remove_padding l pad 0) 0 width pad
            else h:: (fix_padding t (cur_width + 1) width pad);;
let rec extract (l: int list) (i: int) : int list =
	if (i = 2) then l
	else match l with
          | [] -> []
          | h::t -> extract t (i + 1);;


(* (4 - ((width * 3) mod 4)) mod 4 *)

let update_coords (x: int)  (y: int)  (width: int) : (int * int) =
        if (x = width - 1) then (0, y+1)
        else (x + 1, y);;
