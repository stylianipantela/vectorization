open Types;
type 'a vertex = ('a * 'a) ;;
type 'a path = ('a vertex list * biColor) ;;

(*- Use the graph to get the list of paths. First, get the left most top post vertex (using the right
implementation of get_vertex). Follow the arrows (edges) from this vertex, until we get back to
the first vertex. Extract this path from the graph (by extracting the edges, and then the vertices
without edges) and "save" it in the path list. Repeat the process until the graph is empty*)

let squeeze (l: int vertex list) : int vertex list =
  let rec_remove (l: int vertex list) (v: int vertex) : int vertex list =
    match l with
      | [] -> []
      | h::t -> if (v = h) then t
                else rec_remove t v
  in 
  let rec_squeeze (l: int vertex list) (frontier: int vertex list) : int vertex list =
    match l with
      | [] -> List.rev frontier
      | h::t -> if (List.mem h frontier) then (rec_squeeze t (rec_remove frontier h) 
                else (rec_squeeze t (h::frontier)
  in
  match l with
    | [] -> []
    | h::t -> h::(rec_squeeze t [])
 ;;


let follow_vertex (g: IntVertexGraph.graph) (n: IntVertexGraph.node) : int path list
  let rec helper_follow (g: IntVertexGraph.graph) (lst: IntVertexGraph.node list) =
      

let rec pathlist (graph: graph) : ('a path) list =
  match (get_vertex graph) with
    | Some n -> (match (outneighbors graph n) with
	           | [] -> []
		   | h::_ -> [n::h] @ pathlist (remove
	
    | None -> 


  
