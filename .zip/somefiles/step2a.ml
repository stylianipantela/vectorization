type vertex = int * int

module type POLYGON =
sig
	type polygon
    type direction
    type index
    type segment
    val find_direction : vertex -> vertex -> direction
    val run_tests : unit -> unit
    val direction : vertex list -> index -> index -> direction list

    (* Calculates the cyclic difference between two vertices, defined in pg. 6*)
    val cyclic_difference : int -> int -> int -> int

    (* For each pair of vertices, calculate the penalty associated*)
    val penalty : int -> int -> vertex array ref -> float

    (* Composes all functions*)
    val optimize : vertex list -> segment list array ref

    (* determines whether a line approximates the path (definition in pg. 5)*)
    val approximates : vertex array ref-> index -> index -> index -> bool

end

module GenPolygon: POLYGON =
    struct
        exception Impossible
        exception Empty
        type polygon = vertex list
        type direction= South | North | East | West
        type segment = (int * float)
        type index = int
        
        let find_direction (v1 : vertex) (v2: vertex) : direction =
	        let ((a, b), (c, d)) = (v1, v2) in
	        match (c-a), (d-b) with
	        | (0, 1) -> North
	        | (1, 0) -> East
	        | (0, -1) -> South
	        | (-1, 0) -> West
	        | (_,_) -> raise Impossible
	    
	    (* Modified this so that it only returns the direction list within
	        certain indices *)
	    let rec direction (vlist: vertex list) (a:index) (b:index): direction list =
	        let ar= Array.of_list vlist in
	        let rec ind (sub: vertex array) (current: index) (final: index) 
	            (total: direction list): direction list =
	           if (current = final) then total
	           else 
	                ind sub (current+1) final ((find_direction (Array.get sub current)
	                (Array.get sub (current+1))) :: total) in
	        ind ar a b [];;
	    
	    (* Returns true if all four directions occur in the list *)
	    let rec check_direction (d: direction list): bool =
	        (* Check if one direction occurs*)
	        let rec check_helper (d: direction list) (dir: direction) =
		        match d with
		        |[]-> false
		        |hd::tl -> ((hd=dir)||(check_helper tl dir)) in
	        ((check_helper d East)&&(check_helper d West)
	        &&(check_helper d North)&&(check_helper d South))
	    
	    let test_directions () =
             let vertex1 = (0,0) in
             let vertex2 = (1,0) in
             let vertex3 = (1,1) in
             let vertex4 = (0,1) in
             assert((find_direction vertex1 vertex2) = East);
             assert((find_direction vertex2 vertex3) = North);
             assert((find_direction vertex3 vertex4) = West);
             assert((find_direction vertex4 vertex1) = South);
            
             let vlist=(vertex1::vertex2::vertex3::vertex4::[]) in
             assert((direction vlist 0 3) = [West;North;East]);
             assert((check_direction (direction vlist 0 3))= false);
            
             let vlist2=(vertex1::vertex2::vertex3::vertex4::vertex1::[]) in
             assert((direction vlist2 0 4) = [South; West; North; East]);
             assert((check_direction (direction vlist2 0 4))= true);
             ()
	    
	    (* pass in indices of the start and end vertices 
	        and the length of total closed path*)
	    let cyclic_difference (i: index) (j: index) (length: index): int =
	        if (i<=j) then j-i else (j-i+length) 
	    
	    (* Find the slope of a straight line between two endpoints *)
	    let slope (v1: index) (v2: index) (a: vertex array ref): float =
	        match (Array.get (!a) (v1), Array.get (!a) (v2)) with
	        |((x1,y1),(x2,y2))-> 
            (((float_of_int y2) -. (float_of_int y1))
            /.((float_of_int x2) -. (float_of_int x1)))
        
        let distance_pts (a:index) (b:index) (vlist: vertex array ref): float = 
		        let ((x1a, y1a), (x2a, y2a)) = (Array.get !vlist a, Array.get !vlist b) in
		        let ((x1, y1), (x2, y2)) = ((float_of_int x1a, float_of_int y1a),
		                                    (float_of_int x2a, float_of_int y2a)) in
                sqrt((x2-.x1) *. (x2-.x1) +. (y2-.y1) *. (y2-.y1))
            
        (* If directly above, then just return that distance*)    
        let dist_seg_pt (i: index)(a1: index)(a2: index) (vlist: vertex array ref):float=
            let (i1,i2)= Array.get !vlist i in
            let (x1,y1)= Array.get !vlist a1 in
            let (x2, y2)= Array.get !vlist a2 in
            if (x2 =x1) then (float_of_int(abs(i2-y1)))
            else if (y2=y1) then (float_of_int(abs(i1-x1)))
            else if (i1 =x1 && i1=x2) then (0.0)
            else if (i2=y1 && i2=y2) then (0.0)
            else if (i1=x1) then (float_of_int(abs(y1-i2)))
            else if (i1=x2) then (float_of_int(abs(y2-i2)))
            else if (i2=y1) then (float_of_int(abs(x1-i1)))
            else if (i2=y2) then (float_of_int(abs(x2-i1)))
            else
            ((distance_pts i a1 vlist) *. (distance_pts i a2 vlist) /. (distance_pts a1 a2 vlist))
            
        (*(* Note I changed distance_seg_pt to dist_seg_pt to make lines < 80*)
        let dist_seg_pt (a: vertex array ref)(i: index)(a1: index)(a2: index):float=
	        let ((x1,y1),m,(x2,y2)) = ((Array.get (!a) i),
	                                    (slope a1 a2 a),(Array.get !a a1)) in
	        let (x3,x4,y3,y4) = (float_of_int x1,float_of_int x2,
	                            float_of_int y1,float_of_int y2) in
	            (abs_float (y3-.(m*.x3)-.(y4-.m*.x4)))/.(sqrt (m**2. +. 1.))
             *)
                
         (* current index, start index, end index, vlist, total sum*)
	     let rec summation (iterator: index) (start: index) (final:index)(vlist: vertex array ref) 
	        (total: float): float =
		            if (iterator=final) then (total) 
		            else (summation (iterator+1) start final vlist (total +. 
		            (dist_seg_pt iterator start final vlist)))

	    
	    (* Calculates the penalty for a straight line between two vertices *)
	    let penalty (i1:index) (i2:index) (vlist: vertex array ref): float =
            ((distance_pts i1 i2 vlist) *. 
            sqrt ( (summation i1 i1 i2 vlist 0.) 
            /.(float_of_int (cyclic_difference i1 i2 (Array.length !vlist)))))
        
        (* Check that there exists a straight line that approximates 
            the path between two vertices.
            Pass in the array ref, the starting vertex twice, then the 
            ending index of the line segment *)
        let rec approximates (a: vertex array ref) (current: index) (start: index) (endv: index): bool =
	        if (start=endv) then true else
	        (((dist_seg_pt current start endv a)<= 1.0) && 
	            (approximates a (current+1) start endv));;
	    
	    (* Modifies the array by inserting the given index and penalty into 
	        the list of all possible segments*)
	    let add_to (total: 'a array ref)(ind: index)(endv: index)(ar: 'b array ref): unit= 
            let original= (Array.get !total ind) in
            (Array.set (!total) ind ((endv, (penalty ind endv ar))::original))
        
        (* Finds all possible segments given a list of vertices
	       returns list of (endpoint, penalty) *)
        let optimize (x: vertex list): segment list array ref  =
            let rec forward (s: vertex array ref) (current: index) 
            (stored: segment list array ref): unit = 
            
                (* Determines if there is a straight line between
                   one vertex (cur) and any of the other vertices (next)*)
                let rec sub_forward (s2: vertex array ref) (cur: index) 
                (next: index) (total: segment list array ref): unit =
                    if (next = (Array.length !s)-1) then () 
                    else (
                        if (approximates s2 cur cur next)
                        (* check for 4 direction is now here *)
                        &&((check_direction (direction x cur next))=false) then 
                        (add_to total cur next s2; 
                        (sub_forward s2 cur (next+1) total))) in
                        
                (* Goes through all the permutations of the vertices *)
                if (current = ((Array.length !s)-1)) then ()
                else (let _ = (sub_forward s current 0 stored) in
		        let _ = (forward s (current+1)) in ()) in
                let s =ref ( Array.of_list x) in
                
            (let empty = ref (Array.make (Array.length !s) [(-1, 0.0)]) in
            forward s 0 empty;
	    empty)

  
        (* Initializes the array with index values: length, penalty, vertices *)
        let rec 
        generate_polygon (ar: segment list array ref) (current: index) (length: index)
        (penalty: float) (vertices: index list): (index * float * (index list)) list   =
            if (current = ((Array.length !ar)-1)) then [length, penalty, vertices]
            else
            match (Array.get !ar current) with
            | [] -> [length, penalty, vertices]
            | hd::tl -> let (vertex2, penalty2) = hd in
                (generate_polygon ar vertex2 (length+1) (penalty+.penalty2) (vertices @ [vertex2])) 
                @ (sub_polygons tl ar current length penalty vertices)   
            
        and                
        sub_polygons (tail: segment list)(ar: segment list array ref) 
        (current: index) (length: index) (penalty: float) (vertices: index list) : 
        (index * float * (index list)) list = 
            match tail with 
            | [] -> []
            | hd:: tl -> let (v1, p1) = hd in 
            generate_polygon ar v1 (length+1) (penalty +. p1) (vertices @[v1]) 
             @ (sub_polygons tl ar current length penalty vertices)
;;
        (* Helper for test_optimize *)
	    let print m = Array.iter 
	      (fun lst -> 
	            let rec print l: unit =
			        match l with
			        | [] -> Printf.printf "newline";
			        | (a,b) :: tl -> ((Printf.printf "(%i, %f)\n" a b);
			        print tl) in
	             print lst) m
	       ;;
	       
        let test_generate_polygon ()= 
            let s1 =(1,2.0) in
            let s2 =(3, 4.0) in
            let s3 =(3,2.0) in 
            let v0= [s1; s2] in
            let v1= [(3,2.0); (5, 1.0); (-1, 0.0)] in
            let v2= [] in
            let v3= [(4, 0.75); (5, 0.8); (-1, 0.0)] in
            let v4= [(5, 1.3); (-1, 0.0)] in
            let v5= [] in*)
            let ar= ref (Array.make 1 []) in
            let _ =print ar in
            assert(1=2);
            let _ =Array.set !ar 0 v0 in 
            let _ =Array.set !ar 1 v1 in 
            let _ =Array.set !ar 2 v2 in 
            let _ =Array.set !ar 3 v3 in 
            let _ =Array.set !ar 4 v4 in 
            let _ =Array.set !ar 5 v5 in
            assert(1=1);
            (*generate_polygon ar 0 0 0.0 []*)
	        () 
	     let rec reduce f u xs =
            match xs with
            | [] -> u
            | hd::tl -> f hd (reduce f u tl) 
            
        (* Finds the best fit polygon: finding first the shortest length 
            and then the smallest penalty*)
        let compare (lst: (index * float * index list) list): index list = 
            match lst with
            | [] -> []
            | hd::tl ->
                let (l1, p1, v1) = hd in
    	        let len =  reduce (fun (x, _, _) y -> (if x<y then x else y)) l1 tl in 
     	        let pen =  reduce (fun (_, x, _) y -> (if x<y then x else y)) p1 tl in
     	        match  (List.filter (fun (a1, a2, _) -> ( len = a1 && pen =a2)) lst) with
     	         | [] -> []
		         | hd::tl -> match hd with |(_, _, c) -> c
	    
	      let test_num () =
	        let a=1 in
	        let b=7 in
	        assert((cyclic_difference a b 0)=6);
	        let vertex1 = (0,0) in
	        let vertex2 = (1,0) in
	        let vertex3 = (1,1) in
	        let vertex4 = (0,1) in
	        let vlist=(vertex1::vertex2::vertex3::vertex4::[]) in
	        let aref = ref (Array.of_list vlist) in
	        (*assert((slope 0 1 aref)=0.);
	        assert((slope 0 2 aref)=1.);
	        assert((slope 1 3 aref)=(-1.0));
	        assert((slope 3 1 aref)=(-1.0));*)
	        let _ =Printf.printf "%f" (dist_seg_pt  1 0 2 aref) in
	        (* exception: slope fails on vertical lines! *)
	        assert((dist_seg_pt 1 0 2 aref)=1.0);
	        let v0 = (1,1) in
	        let v1 = (1,2) in
	        let v2 = (1,3) in
	        let v3 = (2,4) in
	        let v4 = (2,5) in
	        let v5 = (3,5) in
	        let v6 = (4,5) in
	        let v7 = (4,4) in
	        let v8 = (4,3) in
	        let v9 = (4,2) in
	        let v10 = (4,1) in
	        let v11 = (3,0) in
	        let v12 = (2,0) in
	        let v13 = (1,1) in 
	        let complist = (v0::v1::v2::v3::v4::v5::v6::v7::v8::v9::v10::v11::v12::v13::[]) in
	        let acompref = ref(Array.of_list complist) in
	        assert(distance_pts 0 2 acompref = float_of_int (2));
	        assert(distance_pts 2 8 acompref = float_of_int (3));
	        let _ =Printf.printf "HERE\n" in
	        
	        let _ = Printf.printf "%f\n" (dist_seg_pt 3 2 8 acompref) in
	        let _ = Printf.printf "%f\n" (dist_seg_pt 4 2 8 acompref) in
	        let _ = Printf.printf "%f\n" (dist_seg_pt 5 2 8 acompref) in
	        let _ = Printf.printf "%f\n" (dist_seg_pt 6 2 8 acompref) in
	        let _ = Printf.printf "%f\n" (dist_seg_pt 7 2 8 acompref) in
	        let _ =Printf.printf "END\n" in
	        
	        let _ = Printf.printf "%f\n" (summation 2 2 8 acompref 0.) in
	        let _ = Printf.printf "%f\n" (float_of_int (cyclic_difference 0 2 14)) in
	        let _ = Printf.printf "%f\n" (penalty 0 2 acompref) in
	        let _ = Printf.printf "%f\n" (penalty 2 8 acompref) in

	        (*assert(approximates
	        assert(add_to
	        assert(optimize*) 
	        () 
	        
        let test_optimize() =
            let lst = [(1,1); (1,2); (1,3); (2,4); (2,5); (3,5); (4,5); (4,4); (4,3);
                    (4,2); (4,1); (3,0); (2,0); (1,1)] in
            let result =optimize lst in
	        let _ = Printf.printf "here" in
            print !result;
	        ()
	  
	    let test_compare () = 
              let lst = [(3, 2.0, [1;2;3;4]); (3, 1.0, [2;4;6]); (3, 0.5, [3;5;7]);
			 (4, 1.0, [5;6;8]); (5, 6.0, [2;3;4])] in
              assert ((compare lst) = [3;5;7]);
	        ()
	
	    let run_tests () =
	        test_directions ();
	        test_num ();
	        (*test_optimize();*)
	        test_compare();
	        ()

    end

let _ = GenPolygon.run_tests ()



      
             
       
