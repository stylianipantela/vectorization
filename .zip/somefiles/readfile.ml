(* BITMAPFILEHEADER is 14 bytes long, BITMAPINFOHEADER is 40 bytes long
So, skip the first 54 bytes, i.e. elements of the array
width = 18-22 arrays
height = 22-2
padding = (4 - (width * 3) mod 4) mod 4;
*)

let get_bytes_from_file filename : int list =
  let ch = open_in filename in
  let lst = ref [] in
  try
    while true;
    do
      lst := (input_char ch) :: (!lst);
    done;
    []
  with End_of_file ->
    close_in ch;
    List.map (int_of_char) (List.rev (!lst))
;;
exception ContractViolation;;
exception BlackWhite;;

let bitmap_to_matrix (l: int list) : BicolorMatrix.matrix =
  let length = List.length l in
  if (length <= 54) then raise ContractViolation
  else if (not ((length - 54) mod 3 = 0)) then raise ContractViolation
  else(
    let width = (List.nth l 22) + ((List.nth l 23) * 16)) + 
                ((List.nth l 24) * 16 * 16) + ((List.nth l 25) * 16 * 16) in
    let height = (List.nth l 26) + ((List.nth l 27) * 16) + 
                 ((List.nth l 28) * 16 * 16) + ((List.nth l 29) * 16 * 16) in
    let padding = (4 - ((width * 3) mod 4)) mod 4 in
    let myMatrix =  BicolorMatrix.initialize height width in
    let rec extract (l: char list) (i: int) : char list =
      if (i = 54) then l
      else match l with
        | [] -> []
        | h::t -> extract t (i + 1) in

    let rec fix_padding (l: char list) (cur_width: int) (width: int) (pad: int) : char list =
      let rec remove_padding (l: char list) (pad: int) (cur_pad: int) : char list =
        if (cur_pad = pad) then l
        else( match l with
	       | [] -> []
	       | h::t -> remove_padding t pad (cur_pad + 1)) in
      match l with
	| [] -> []
	| h::t -> if (cur_width = width) 
                  then fix_padding (remove_padding l pad 0) (cur_width + pad) width pad
                  else h:: (fix_padding t (cur_width + 1) width pad) in
      
      let update_coords (x: int)  (y: int)  (width: int) : (int * int) =
        if (y = width - 1) then (x+1, y)
        else (x, y+1) in

      let rec store (l: char list) (m: BicolorMatrix.matrix) ((x,y): (int * int)) (width: int) : BicolorMatrix.matrix in
        match l with
          | [] -> m
          | h::[] -> raise ContractViolation
          | h::t::[] -> raise ContractViolation
          | r::g::b::t -> if (r,g,b) = (0,0,0) then store t (BicolorMatrix.set m y x Black) (width: int)  ( )
                        else if (r,g,b) = (255,255,255)
                           then store t (BicolorMatrix.set m y x White) (update_coords x y width) width
                        else raise BlackWhite
    in
  store (fix_padding (extract l 0) 0 width padding) myMatrix (0,0))
;;
  


let rec print_list lst =
  match lst with
    | [] -> Printf.printf ""
    | hd :: tl -> Printf.printf "%x\n" (int_of_char hd); (print_list tl)
;;

print_list (get_bytes_from_file "testinputs/small.bmp");;
