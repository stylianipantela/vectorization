open Types;;
open Step1;;


(* implementation of graph with int vertices *)
module IntVertexGraph : (DIRECTEDGRAPH with type node = (int vertex)) =
struct
  type node = (int vertex)
  type graph = (node * node list) list

  let empty = []


  let isequal (v1: node) (v2: node) = 
    let (x1,y1) = v1 in
    let (x2,y2) = v2 in
    ((x1 = x2) && (y1 = y2))

  let rec inlist (lst: node list) (v1: node) = 
    match lst with
      | [] -> false
      | hd :: tl ->
	(isequal v1 hd) || (inlist tl v1)


  let outneighbors (g: graph) (v: node) = 
    let rec outhelper (g0: graph) (v0: node) =
      match g0 with
	| [] -> []
	| hd :: tl -> 
	  let (v1, nb) = hd in
	  if (isequal v1 v0)
	  then nb
	  else outhelper tl v0
    in 
    outhelper g v

  let inneighbors (g: graph) (v: node) = 
    let rec inhelper (g0: graph) (v0: node) =
      match g0 with
	| [] -> []
	| hd :: tl -> 
	  let (v1, nb) = hd in
	  if (inlist nb v0)
	  then v1 :: (inhelper tl v0)
	  else inhelper tl v0

    in 
    inhelper g v

  let vertices (g: graph) = 
    let rec verthelper (g0: graph) =
      match g0 with
	| [] -> []
	| hd :: tl ->
	  let (v, nb) = hd in
	  v :: (verthelper tl)
    in
    verthelper g
	

  let add (g: graph) (v: node) =
    if (inlist (vertices g) v) then g
    else (v, []) :: g

  let rec remove_from_list (lst: node list) (v: node) =
    match lst with
      | [] -> []
      | hd :: tl -> 
	if (isequal v hd) then remove_from_list tl v
	else hd :: (remove_from_list tl v)
  
  let remove (g: graph) (v: node) = 
    let rec remove_helper (g0: graph) (v0: node) = 
      match g0 with
	| [] -> []
	| hd :: tl -> 
	  let (v1, nb) = hd in
	  if (isequal v1 v0) then remove_helper tl v0
	  else (v1, remove_from_list nb v0) :: remove_helper tl v0
    in
    remove_helper g v


  let rec add_to_list (lst: node list) (v: node) = 
    match lst with
      | [] -> [v]
      | hd :: tl -> if (isequal v hd) then lst
	else hd :: (add_to_list tl v)


  let set_edge (g: graph) (v1: node) (v2: node) =
    let rec sethelper (g0: graph) (vt1: node) (vt2: node) =
      match g0 with
	| [] -> []
	| hd :: tl -> 
	  let (v, nb) = hd in
	  if (isequal vt1 v)
	  then (vt1, add_to_list nb vt2) :: tl
	  else hd :: (sethelper tl vt1 vt2)
    in
    if (inlist (vertices g) v2)
    then sethelper g v1 v2
    else g


  let remove_edge (g: graph) (v1: node) (v2: node) =
    let rec removehelper (g0: graph) (vt1: node) (vt2: node) =
      match g0 with
	| [] -> []
	| hd :: tl -> 
	  let (v, nb) = hd in
	  if (isequal vt1 v)
	  then (vt1, remove_from_list nb vt2) :: tl
	  else hd :: (removehelper tl vt1 vt2)
    in
    removehelper g v1 v2



  let rec list_min (lst: int list) : int =
    match lst with
      | [] -> max_int
      | hd :: tl -> min hd (list_min tl)


  (* gets the left most top most vertex *)
  let get_vertex (g: graph) =
    let vlist = vertices g in
    match vlist with
      | [] -> None
      | hd :: tl -> 
	let xlist = List.map (fun (a,b) -> a) vlist in
	let minx = list_min xlist in
	let leftmost = List.filter (fun (a,b) -> (a = minx)) vlist in
	let ylist = List.map (fun (a,b) -> b) leftmost in
	let miny = list_min ylist in
	Some (minx, miny)

end


let isequal (v1: IntVertexGraph.node) (v2: IntVertexGraph.node) = 
  let (x1,y1) = v1 in
  let (x2,y2) = v2 in
  ((x1 = x2) && (y1 = y2))
;;

exception NoNeighbors ;;


let get_next (g: IntVertexGraph.graph) (v: IntVertexGraph.node) : IntVertexGraph.node =
  let out = IntVertexGraph.outneighbors g v in
  match out with
    | [] -> raise NoNeighbors
    | hd :: tl -> hd
;;


let rec cycle_ending_in (g: IntVertexGraph.graph) (first: IntVertexGraph.node)
    (current: IntVertexGraph.node list) : (IntVertexGraph.node list) =
  match current with
    | [] -> 
      let outnb = get_next g first in
      cycle_ending_in (IntVertexGraph.remove_edge g first outnb) first [outnb] 
    | hd :: tl -> 
      if (isequal first hd) then (first :: current) @ [first]
      else 
	let outnb = get_next g hd in
	cycle_ending_in (IntVertexGraph.remove_edge g hd outnb) first (outnb :: current) 	  
;;

(* gets a graph, and returns a path which is a cycle that starts and ends
   in the left most top most vertex *)
let get_cycle (g: IntVertexGraph.graph) : (IntVertexGraph.node list) =
  match (IntVertexGraph.get_vertex g) with
    | None -> []
    | Some v ->
      List.rev (cycle_ending_in g v [])
;;


(* removes the all internal cycles *)
let squeeze (l: int vertex list) : int vertex list =
  let rec rec_remove (l: int vertex list) (v: int vertex) : int vertex list =
    match l with
      | [] -> []
      | h::t -> if (v = h) then t
        else rec_remove t v
  in 
  let rec rec_squeeze (l: int vertex list) (frontier: int vertex list) : int vertex list =
    match l with
      | [] -> List.rev frontier
      | h::t -> if (List.mem h frontier) 
	then (rec_squeeze t (rec_remove frontier h))
	else (rec_squeeze t (h::frontier))
  in
  match l with
    | [] -> []
    | h::t -> h::(rec_squeeze t [])
;;




(* removes all edges that correspond to a sequence of connected nodes *)
let rec remove_edges (g: IntVertexGraph.graph) (lst: IntVertexGraph.node list) 
    : IntVertexGraph.graph =
  match lst with
    | [] -> g
    | hd :: [] -> g
    | hd1 :: hd2 :: tl -> remove_edges (IntVertexGraph.remove_edge g hd1 hd2) (hd2 :: tl)
;;


(* removes all the nodes with no edges from a graph *)
let remove_single_nodes (g: IntVertexGraph.graph) : IntVertexGraph.graph =
  let nodes = IntVertexGraph.vertices g in
  let rec remove_list (g0: IntVertexGraph.graph) (lst: IntVertexGraph.node list) =
    match lst with
      | [] -> g0
      | hd :: tl -> 
	match (IntVertexGraph.outneighbors g0 hd, IntVertexGraph.inneighbors g0 hd) with
	  | ([],[]) -> remove_list (IntVertexGraph.remove g0 hd) tl
	  | _ -> remove_list g0 tl
  in
  remove_list g nodes
;;




let g = bitmap_to_graph test ;;
let cycle = get_cycle g ;;
let newcycle = squeeze cycle;;
let g0 = remove_edges g newcycle;;
let newgraph = remove_single_nodes g0;;


save "test3.svg" ("<?xml version=\"1.0\" standalone=\"no\"?>
<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" 
  \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">
<svg version=\"1.1\"
     xmlns=\"http://www.w3.org/2000/svg\">\n"^(svg_graph (newgraph))^"</svg>");


