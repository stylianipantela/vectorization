open Images;;
open OImages;;
open Info;;

let files = ref [] in
Arg.parse []
  (fun s -> files := s :: !files)
  "read src";

let src = OImages.rgb24 (OImages.load src []) in

(* call the matrix module *)
let myMatrix = initiliaze src#width src#height;

let read img =
  for x = 0 to src#width - 1 do
    for y = 0 to src#height - 1 do
      let rgb = src#get x y in
      match (rgb.r, rgb.g, rgb.b) with
      |(0,0,0) -> set myMatrix y x Black
      |(255,255,255) -> myMatrix set y x White
      |_ -> () (* raise exception *)
    done
  done in
read src

