
let print_list (print: 'a -> unit) (lst: 'a list) : unit =
  let rec print_list_h print lst =
    match lst with
      | [] -> Printf.printf ""
      | hd::tl -> print hd; Printf.printf ";"; print_list_h print tl
  in
  Printf.printf "["; print_list_h print lst; Printf.printf "]"
;;

let print_int n = Printf.printf "%d" n ;;

let print_float f = Printf.printf "%f" f ;;

let print_bla (l,f) = Printf.printf "(";
 print_list print_int l;
Printf.printf ",";
print_float f;
Printf.printf ")";

;;


let print_bla2(l,f) = Printf.printf "(";
 print_list print_int l;
Printf.printf ",";
print_int f;
Printf.printf ")";

;;

let rec choose_list n m = 
  match n with 
    | 0 -> if (m = 0) then [[]] else []
    | k -> (choose_list (n-1) m)@(List.map (fun lst -> lst @ [n-1]) (choose_list (n-1) (m-1)))
;;


let get_best arr n =
  let totalsum = Array.fold_right (+) arr 0 in
  


  let summm lst = List.fold_right (fun x prev -> (Array.get arr x)+prev) lst 0 in


  let sums = List.map (fun lst -> (lst,summm lst)) (choose_list (2*n) n) in
(*Printf.printf "\n\n\nTotal sum: "; print_int totalsum;

  Printf.printf "\n\n\nSums list: "; print_list print_bla2 sums;
  Printf.printf "\n\n\nNewsums: "; print_list print_bla2 newsums;

  Printf.printf "\n\n\nSorted: "; print_list print_bla2 newsums; *)

  let newsums = List.map (fun (l,s) -> (l,abs (2*s - totalsum)) ) sums in



  let compare_bla (l1,f1) (l2,f2) = compare f1 f2 in 
  let sorted = List.sort compare_bla newsums in


  let (l,v) = List.hd sorted in
  Printf.printf "\n\n\nRESULT: ";
  print_int v;
;;


let run () = 
  Printf.printf "\n1:";
  get_best [|1;2;3;4;5;6;7;8|] 4;

  Printf.printf "\n2:";
  get_best [|1;1;1;1;1;1;1;1000|] 4;


  Printf.printf "\n3:";
get_best [|13;17|] 1


;;

run ();;
